package network.observer;


public interface Observer {
	public void update();
}
