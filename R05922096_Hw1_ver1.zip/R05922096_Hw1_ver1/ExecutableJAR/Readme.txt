Required Environment :
JRE version should be at least 1.7



How to run program :
command$ java -jar BPN.jar
	or
command$ java -jar BPN.jar hw1data.dat 2,8,6,1 1000 0.5 
	or
command$ java -jar BPN.jar <File> <network> <iteration> <learningRate>
	or 
run shell script -> run.sh / run2-4-3-1.sh



